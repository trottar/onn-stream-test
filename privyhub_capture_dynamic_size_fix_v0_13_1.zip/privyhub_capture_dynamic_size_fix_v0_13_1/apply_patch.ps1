param(
    [string]$ProjectRoot = ""
)

$ErrorActionPreference = "Stop"

if (
    [string]::IsNullOrWhiteSpace(
        $ProjectRoot
    )
) {
    $ProjectRoot =
        (Get-Location).Path
}

$ProjectRoot =
    [System.IO.Path]::GetFullPath(
        $ProjectRoot
    )

python `
    (Join-Path $PSScriptRoot "apply_patch.py") `
    --project-root `
    $ProjectRoot

if ($LASTEXITCODE -ne 0) {
    throw "WGC Dynamic Size Fix v0.13.1 failed."
}

Write-Host ""
Write-Host "No Android rebuild is needed."
Write-Host "No companion restart is needed if no game is currently streaming."
Write-Host ""
Write-Host "Launch one of the games that was previously black and test normally."
Write-Host "The v0.13 capture diagnostic JSON will remain available for verification."
