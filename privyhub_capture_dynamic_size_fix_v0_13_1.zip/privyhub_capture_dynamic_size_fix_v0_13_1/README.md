# PrivyHub WGC Dynamic Size Fix v0.13.1

The v0.13 diagnostic identified the black-screen bug.

A failing game started with WGC output:

```text
881x763
```

and then changed to:

```text
941x763
```

The existing bridge had locked FFmpeg's raw-video input envelope to the first
size. Every later 941x763 frame was therefore discarded. The stream continued
encoding the last accepted frame, which made audio/controller work while video
appeared black or frozen.

## Fix

Stable-size games keep the exact existing fast path:

```text
WGC ndarray -> tobytes -> FFmpeg
```

Only a frame whose WGC dimensions differ from the original envelope takes the
new compatibility path.

### Small size changes (<= 15%)

The frame is center cropped and/or padded back into the original envelope.

### Larger size changes

The frame is aspect-preserving resized with OpenCV into the original envelope
and centered with black padding.

OpenCV/NumPy are already dependencies of the project-local windows-capture
runtime; this adds no new package.

## Why keep a fixed output envelope?

FFmpeg reads this bridge as raw BGRA video. Rawvideo has fixed dimensions, so
changing byte dimensions mid-stream would corrupt framing unless FFmpeg were
restarted.

Normalizing only exceptional resized frames preserves:

```text
current FFmpeg/NVENC process
GOP=15
7 Mb/s source video
8+1 FEC
audio smoothing
controller
decoder
```

and avoids a visible stream restart.

## Diagnostics retained

v0.13 diagnostics remain active and add:

```text
size_mismatch_frames
normalized_size_frames
normalization_crop_pad_frames
normalization_scaled_frames
normalization_failures
```

`size_mismatch_drops` now means a resized frame that actually could not be
normalized.

## Apply

```powershell
.\privyhub_capture_dynamic_size_fix_v0_13_1\apply_patch.ps1
```

No Android rebuild is required.

No companion restart is required if no native game stream is currently
running. Start a fresh game session after applying.

Test one of the games that was previously black. If video now appears, the
diagnosis is confirmed directly. The newest file under:

```text
logs\games\capture_diagnostics\
```

can verify that resized frames were normalized instead of discarded.
