from __future__ import annotations

import argparse
import ast
import shutil
import sys

from datetime import datetime
from pathlib import Path


RELATIVE = Path(
    "companion/native_wgc_bridge.py"
)


def replace_once(
    text: str,
    old: str,
    new: str,
    label: str,
) -> str:
    count = text.count(old)

    if count != 1:
        raise RuntimeError(
            f"{label}: expected exactly one anchor, found {count}"
        )

    return text.replace(
        old,
        new,
        1,
    )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--project-root",
        required=True,
    )
    args = parser.parse_args()

    project_root = Path(
        args.project_root
    ).resolve()

    target = (
        project_root /
        RELATIVE
    )

    if not target.is_file():
        raise RuntimeError(
            f"Expected project file not found: {target}"
        )

    original = target.read_text(
        encoding="utf-8"
    ).replace(
        "\r\n",
        "\n",
    )

    if (
        "PrivyHub WGC Dynamic Size Fix v0.13.1"
        in original
    ):
        print(
            "WGC Dynamic Size Fix v0.13.1 is already installed."
        )
        return 0

    for token in (
        "PrivyHub WGC Capture Compatibility Probe v0.13",
        "size_mismatch_drops",
        "near_black_samples",
        "largest_visible_hwnd",
    ):
        if token not in original:
            raise RuntimeError(
                "This patch expects Capture Compatibility Probe v0.13. "
                "Missing token: "
                + token
            )

    text = original

    text = replace_once(
        text,
        '''        from windows_capture import (
            Frame,
            InternalCaptureControl,
            WindowsCapture,
        )
''',
        '''        from windows_capture import (
            Frame,
            InternalCaptureControl,
            WindowsCapture,
        )

        import cv2
        import numpy as np
''',
        "runtime imports",
    )

    helper_anchor = '''def _window_probe(
    hwnd: int,
    owner_pid_hint: int = 0,
) -> dict[str, object]:
'''

    helper = r'''def _normalize_bgra_to_envelope(
    frame_buffer,
    source_width: int,
    source_height: int,
    target_width: int,
    target_height: int,
    cv2,
    np,
) -> tuple[bytes, str]:
    if (
        source_width <= 0
        or source_height <= 0
        or target_width <= 0
        or target_height <= 0
    ):
        raise ValueError(
            "Invalid WGC normalization dimensions"
        )

    width_delta = (
        abs(
            source_width -
            target_width
        )
        /
        max(
            1,
            target_width,
        )
    )

    height_delta = (
        abs(
            source_height -
            target_height
        )
        /
        max(
            1,
            target_height,
        )
    )

    if max(
        width_delta,
        height_delta,
    ) <= 0.15:
        canvas = np.zeros(
            (
                target_height,
                target_width,
                4,
            ),
            dtype=np.uint8,
        )

        canvas[
            :,
            :,
            3
        ] = 255

        copy_width = min(
            source_width,
            target_width,
        )
        copy_height = min(
            source_height,
            target_height,
        )

        source_x = max(
            0,
            (
                source_width -
                copy_width
            ) //
            2,
        )
        source_y = max(
            0,
            (
                source_height -
                copy_height
            ) //
            2,
        )

        target_x = max(
            0,
            (
                target_width -
                copy_width
            ) //
            2,
        )
        target_y = max(
            0,
            (
                target_height -
                copy_height
            ) //
            2,
        )

        canvas[
            target_y:
                target_y +
                copy_height,
            target_x:
                target_x +
                copy_width,
            :,
        ] = frame_buffer[
            source_y:
                source_y +
                copy_height,
            source_x:
                source_x +
                copy_width,
            :,
        ]

        return (
            canvas.tobytes(
                order="C"
            ),
            "center_crop_pad",
        )

    scale = min(
        target_width /
            source_width,
        target_height /
            source_height,
    )

    resized_width = max(
        1,
        min(
            target_width,
            int(
                round(
                    source_width *
                    scale
                )
            ),
        ),
    )

    resized_height = max(
        1,
        min(
            target_height,
            int(
                round(
                    source_height *
                    scale
                )
            ),
        ),
    )

    interpolation = (
        cv2.INTER_AREA
        if scale < 1.0
        else cv2.INTER_LINEAR
    )

    resized = cv2.resize(
        frame_buffer,
        (
            resized_width,
            resized_height,
        ),
        interpolation=interpolation,
    )

    canvas = np.zeros(
        (
            target_height,
            target_width,
            4,
        ),
        dtype=np.uint8,
    )

    canvas[
        :,
        :,
        3
    ] = 255

    target_x = (
        target_width -
        resized_width
    ) // 2

    target_y = (
        target_height -
        resized_height
    ) // 2

    canvas[
        target_y:
            target_y +
            resized_height,
        target_x:
            target_x +
            resized_width,
        :,
    ] = resized

    return (
        canvas.tobytes(
            order="C"
        ),
        "aspect_fit",
    )


def _window_probe(
    hwnd: int,
    owner_pid_hint: int = 0,
) -> dict[str, object]:
'''

    text = replace_once(
        text,
        helper_anchor,
        helper,
        "normalization helper",
    )

    text = replace_once(
        text,
        '''    overwritten_frames = 0
    size_mismatch_drops = 0
    emitted_frames = 0
''',
        '''    overwritten_frames = 0
    size_mismatch_frames = 0
    size_mismatch_drops = 0
    normalized_size_frames = 0
    normalization_crop_pad_frames = 0
    normalization_scaled_frames = 0
    normalization_failures = 0
    emitted_frames = 0
''',
        "normalization counters",
    )

    old_version_block = '''        "version": (
            "PrivyHub WGC Capture Compatibility Probe v0.13"
        ),
        "started_unix_ms": int(
'''
    new_version_block = '''        "version": (
            "PrivyHub WGC Dynamic Size Fix v0.13.1"
        ),
        "dynamic_size_fix": True,
        "normalization_policy": (
            "small_center_crop_pad_large_aspect_fit"
        ),
        "started_unix_ms": int(
'''
    text = replace_once(
        text,
        old_version_block,
        new_version_block,
        "diagnostic version",
    )

    text = replace_once(
        text,
        '''            "overwritten_frames": overwritten_frames,
            "size_mismatch_drops": size_mismatch_drops,
            "late_ticks": late_ticks,
''',
        '''            "overwritten_frames": overwritten_frames,
            "size_mismatch_frames": size_mismatch_frames,
            "size_mismatch_drops": size_mismatch_drops,
            "normalized_size_frames": normalized_size_frames,
            "normalization_crop_pad_frames": (
                normalization_crop_pad_frames
            ),
            "normalization_scaled_frames": (
                normalization_scaled_frames
            ),
            "normalization_failures": normalization_failures,
            "late_ticks": late_ticks,
''',
        "snapshot counters",
    )

    text = replace_once(
        text,
        '''        nonlocal overwritten_frames
        nonlocal size_mismatch_drops
        nonlocal copy_time_total_ms
''',
        '''        nonlocal overwritten_frames
        nonlocal size_mismatch_frames
        nonlocal size_mismatch_drops
        nonlocal normalized_size_frames
        nonlocal normalization_crop_pad_frames
        nonlocal normalization_scaled_frames
        nonlocal normalization_failures
        nonlocal copy_time_total_ms
''',
        "callback nonlocals",
    )

    old_mismatch = '''            if (
                width != source_width
                or height != source_height
            ):
                size_mismatch_drops += 1
                report_mismatch += 1

                if int(
                    diagnostics[
                        "first_mismatch_width"
                    ]
                ) <= 0:
                    diagnostics[
                        "first_mismatch_width"
                    ] = width
                    diagnostics[
                        "first_mismatch_height"
                    ] = height

                diagnostics[
                    "last_mismatch_width"
                ] = width
                diagnostics[
                    "last_mismatch_height"
                ] = height

                if (
                    size_mismatch_drops <= 3
                    or size_mismatch_drops % 120 == 0
                ):
                    print(
                        "WGC size-change frame dropped: "
                        f"{width}x{height}; "
                        f"stream envelope remains "
                        f"{source_width}x{source_height}",
                        file=sys.stderr,
                        flush=True,
                    )

                return
'''

    new_mismatch = '''            needs_size_normalization = (
                width != source_width
                or height != source_height
            )

            if needs_size_normalization:
                size_mismatch_frames += 1
                report_mismatch += 1

                if int(
                    diagnostics[
                        "first_mismatch_width"
                    ]
                ) <= 0:
                    diagnostics[
                        "first_mismatch_width"
                    ] = width
                    diagnostics[
                        "first_mismatch_height"
                    ] = height

                diagnostics[
                    "last_mismatch_width"
                ] = width
                diagnostics[
                    "last_mismatch_height"
                ] = height

                if (
                    size_mismatch_frames <= 3
                    or size_mismatch_frames % 600 == 0
                ):
                    print(
                        "WGC size-change frame will be normalized: "
                        f"{width}x{height} -> "
                        f"{source_width}x{source_height}",
                        file=sys.stderr,
                        flush=True,
                    )
'''

    text = replace_once(
        text,
        old_mismatch,
        new_mismatch,
        "mismatch behavior",
    )

    old_copy = '''            started = time.perf_counter()

            payload = frame.frame_buffer.tobytes(
                order="C"
            )

            copy_ms = (
                time.perf_counter()
                - started
            ) * 1000.0

            if len(payload) != expected_bytes:
                size_mismatch_drops += 1
                report_mismatch += 1
                return
'''

    new_copy = '''            started = time.perf_counter()

            if needs_size_normalization:
                try:
                    (
                        payload,
                        normalization_strategy,
                    ) = _normalize_bgra_to_envelope(
                        frame.frame_buffer,
                        width,
                        height,
                        source_width,
                        source_height,
                        cv2,
                        np,
                    )

                    normalized_size_frames += 1

                    if (
                        normalization_strategy ==
                        "center_crop_pad"
                    ):
                        normalization_crop_pad_frames += 1
                    else:
                        normalization_scaled_frames += 1

                except Exception as exc:
                    normalization_failures += 1
                    size_mismatch_drops += 1

                    if (
                        normalization_failures <= 3
                        or normalization_failures % 120 == 0
                    ):
                        print(
                            "WGC dynamic-size normalization failed: "
                            f"{exc}",
                            file=sys.stderr,
                            flush=True,
                        )

                    return
            else:
                payload = frame.frame_buffer.tobytes(
                    order="C"
                )

            copy_ms = (
                time.perf_counter()
                - started
            ) * 1000.0

            if len(payload) != expected_bytes:
                size_mismatch_drops += 1
                normalization_failures += 1
                return
'''

    text = replace_once(
        text,
        old_copy,
        new_copy,
        "normalized frame copy",
    )

    text = replace_once(
        text,
        '''                    f"size_drop={report_mismatch} "
''',
        '''                    f"size_change={report_mismatch} "
                    f"normalized={normalized_size_frames} "
                    f"norm_fail={normalization_failures} "
''',
        "performance logging",
    )

    text = text.replace(
        '''                    size_mismatch_drops,
''',
        '''                    size_mismatch_frames,
''',
        1,
    )

    text = text.replace(
        '''                        f"size_mismatch_drops={warning_state[3]}",
''',
        '''                        f"size_mismatch_frames={warning_state[3]} "
                        f"normalized={normalized_size_frames} "
                        f"normalization_failures={normalization_failures}",
''',
        1,
    )

    text = replace_once(
        text,
        '''        "PrivyHub WGC Capture Compatibility Probe v0.13 active; "
        "stream behavior is unchanged",
''',
        '''        "PrivyHub WGC Dynamic Size Fix v0.13.1 active; "
        "stable-size fast path unchanged",
''',
        "startup banner",
    )

    ast.parse(
        text
    )

    for token in (
        "PrivyHub WGC Dynamic Size Fix v0.13.1",
        "_normalize_bgra_to_envelope",
        "normalized_size_frames",
        "normalization_crop_pad_frames",
        "normalization_scaled_frames",
        "normalization_failures",
        "needs_size_normalization",
    ):
        if token not in text:
            raise RuntimeError(
                "Post-patch verification failed: "
                + token
            )

    stamp = datetime.now().strftime(
        "%Y%m%d_%H%M%S"
    )

    backup = (
        project_root /
        "archive" /
        (
            "capture_dynamic_size_v0_13_1_"
            f"backup_{stamp}"
        ) /
        RELATIVE
    )

    backup.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    shutil.copy2(
        target,
        backup,
    )

    target.write_text(
        text,
        encoding="utf-8",
        newline="\n",
    )

    print(
        f"Backup: {backup}"
    )
    print()
    print(
        "Installed WGC Dynamic Size Fix v0.13.1."
    )
    print()
    print(
        "Only companion/native_wgc_bridge.py was changed."
    )
    print()
    print(
        "Stable-size games retain the existing fast path."
    )
    print(
        "Resized WGC frames are normalized into the original "
        "FFmpeg raw-video envelope instead of being dropped."
    )
    print()
    print(
        "Small changes (<=15%): center crop/pad, no interpolation."
    )
    print(
        "Larger changes: aspect-preserving OpenCV fit/pad."
    )
    print()
    print(
        "No Android rebuild is required."
    )
    print(
        "No companion restart is required if no game is currently streaming."
    )
    print(
        "Launch a fresh previously-black game to test."
    )

    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(
            main()
        )
    except Exception as exc:
        print(
            f"ERROR: {exc}",
            file=sys.stderr,
        )
        raise
